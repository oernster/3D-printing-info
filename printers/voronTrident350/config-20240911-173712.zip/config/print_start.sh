#!/bin/sh
aplay /home/pi/printer_data/config/print_start.wav
