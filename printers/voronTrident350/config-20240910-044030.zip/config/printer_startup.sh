#!/bin/sh
aplay /home/pi/printer_data/config/printer_startup.wav

