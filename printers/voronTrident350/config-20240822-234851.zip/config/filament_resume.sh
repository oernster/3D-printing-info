#!/bin/sh
aplay /home/pi/printer_data/config/filament_resume.wav
